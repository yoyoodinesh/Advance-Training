package arrayFrequency;

import java.util.HashMap;
import java.util.Map;

public class ArrayFrequency {
	
	 public static Map<Integer, Integer> findFrequency(int[] nums) {
		 Map<Integer, Integer> freq = new HashMap<>();
		 int left = 0, right = nums.length - 1;
		 while (left <= right) {
			  if (nums[left] == nums[right]) {
				  freq.put(nums[left], freq.getOrDefault(nums[left], 0) + (right - left + 1));
				  left = right + 1;
	                right = nums.length - 1;
			  }
			  else {
				  right = (left + right) / 2;
			  }
		 }
		 return freq;
	 }

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 int[] nums = { 2, 2, 2, 4, 4, 4, 5, 5, 6, 8, 8, 9 };
		 
		 Map<Integer, Integer> freq = findFrequency(nums);
		 System.out.println(freq);
	}

}
