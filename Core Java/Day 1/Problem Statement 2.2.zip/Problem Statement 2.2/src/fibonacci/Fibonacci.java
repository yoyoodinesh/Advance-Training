package fibonacci;

import java.util.Scanner;

public class Fibonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n, n1, n2, n3, i;
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the 1st no:");
		n1 = scan.nextInt();
		
		System.out.println("Enter the 2nd no:");
		n2 = scan.nextInt();
		
		System.out.println("Enter the total no of numbers to be printed:");
		n = scan.nextInt();
		
		scan.close();
		
		System.out.print(n1 + " " + n2);
		
		for(i=2; i<n; ++i) {
			n3 = n1 + n2;
			System.out.print(" " + n3);
			n1 = n2;
			n2 = n3;  
		}
	}

}
